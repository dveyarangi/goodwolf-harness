**A reply speaks the method:** which question the work is on, the method's step as the person would
name it, what is decided, what is next, where it stops, what it needs from the person. What the
work read, ran or wrote on the way, and what it will read next, is not told; what more the person
hears at an occasion, a skill's `What the person hears` says, in their words. It names no script,
call, check, report, record's internals or hook, and never retells a report: an outcome is one
sentence, a failure is what the person does. Under `debug=on` the machinery is shown as well.

---
name: align
description: Grilling session that challenges current plan against the existing domain model, sharpens terminology, and updates documentation as decisions crystallise. Use to stress-test a plan against their project's language and documented decisions.
---

<straw-dog question="q-0037.0009.0003">Mechanism: not yet</straw-dog>

<what-to-do>

Begin every alignment with a **necessity gate**: name the present customer, the observable problem, and why existing behaviour cannot satisfy it. An accepted requirement or ADR passes by citation. Weak evidence means narrow, postpone, or eliminate — settle that before exploring design. The gate fires late too: a mechanism whose name will not settle is evidence it should not exist. [/impact](../impact/SKILL.md) traces consequences once the need holds.

Problem before machinery: open with the concrete failures and my own earlier words, read back from the records, before any design question. A new term is a decision, not a convenience; when I do not follow, go more concrete.

Interview me relentlessly about every aspect of current work until we reach a shared understanding. Walk down each branch of the design tree, resolving dependencies between decisions one-by-one. For each question, provide your recommended answer. If there are alternatives, show pros/cons/tradeoffs between them.

Ask the questions one at a time, waiting for feedback on each question before continuing. Asking multiple questions at once is bewildering. Do not use platform (Cursor/Claude Code) question format, output plain md.

If a *fact* can be found by exploring the doc corpus or codebase, look it up rather than asking me. The *decisions*, though, are mine - put each one to me and wait for my answer.

<straw-dog question="q-0037.0001.0020">
Decomposing the work during an align is [/ticket](../ticket/SKILL.md)'s, and it calls
[/impact](../impact/SKILL.md) on the draft split. Run that chain and present what it returns as a
suggestion; do not mint. A breakdown reached by unaided grouping is not that chain's output,
however ticket-shaped it looks.
</straw-dog>

Do not enact the plan before I confirm we have reached a shared understanding: the question's `Where it stands` holds the whole, and I have accepted it.


</what-to-do>

<supporting-info>

<straw-dog question="q-0037.0010.0002.0005">
## Good architecture

Goal of architecture is to reduce work on creation and maintenance of the system.

Identify the load-bearing assumption behind the proposed shape; ask yourself - what is the cheapest real example that could prove this design assumption wrong? 

Check it when practical, preferably against external reality rather than our own documents and tests.

If falsified, realign.
If unverified and load-bearing, preserve the uncertainty explicitly.

## Domain awareness

During codebase exploration, also look for existing documentation:

### File structure

Most repos have a single context:

```
/
├── docs/
│   ├── adr/
│   │   ├── 0001-event-sourced-orders.md
│   │   └── 0002-postgres-for-write-model.md
│   ├── architecture.md
│   └── glossary.md
└── src/
```

Create files lazily — only when you have something to write. If no `docs/glossary.md` exists, create one when the first term is resolved. If no `docs/adr/` exists, create it when the first ADR is needed.
</straw-dog>

## During the session

<straw-dog question="q-0037.0010.0001.0001">
### Challenge against the glossary

When the user uses a term that conflicts with the existing language in `docs/glossary.md`, call it out immediately. "Your glossary defines 'cancellation' as X, but you seem to mean Y — which is it?"

This cuts both ways: before *you* propose a name, check the glossary yourself — including its _Avoid_ lists, which are reservations, not suggestions. If every synonym for a concept is avoided, that is a designed constraint telling you which word the project has chosen; work within it rather than proposing around it.
</straw-dog>

<straw-dog question="q-0037.0010.0002.0005">
### Check whether it was already decided

Before treating a question as open, search the ADRs and architecture docs for it. A surprising amount of "open" questions are accepted decisions the code drifted from — the answer then is "implement the ADR", not a fresh trade-off analysis. Cite the deciding document when you find one.
</straw-dog>

### Challenge against the Edge records

<installed by="edge">
**E3** When the plan touches an edge — where the system meets those who consume it or extend it — check
that edge's record under `docs/edge/`. A contradiction with its Contract or Invariants is either a
plan bug or a deliberate contract change, and a contract change is named **breaking or
compatible** out loud before proceeding. As decisions land, write them into the record in the
shape of `.agents/skills/edge/EDGE-FORMAT.md`: a contract change in `Contract` and `Invariants`,
marked `⚠ pending — <ticket>` until its ticket lands and the record set `Normative (tentative)`
while any is pending, a promise without a validator marked **⚠ unguarded**; newly surfaced
edge-scoped concerns as pointers in `Concerns`; staging shifts in `Roadmap`.
</installed>

### Lead with the decisive fact

When recommending between alternatives, find the fact that settles it — a reader count, an import direction, an existing invariant, what a test actually asserts — and lead with it. A pros/cons menu with no decisive fact means you haven't explored enough yet; go look before asking.

### Name the shared assumption

When posing an A-or-B fork, state the assumption both branches share. The user's best answer may dissolve the fork rather than pick a branch — treat "the premise is wrong" as a first-class outcome, not a detour. If a fork keeps resisting resolution, that is usually the sign.

### Sharpen fuzzy language

When the user uses vague or overloaded terms, propose a precise canonical term. "You're saying 'account' — do you mean the Customer or the User? Those are different things."

### Discuss concrete scenarios

When domain relationships are being discussed, stress-test them with specific scenarios. Invent scenarios that probe edge cases and force the user to be precise about the boundaries between concepts.

### Cross-reference with code

When the user states how something works, check whether the code agrees. If you find a contradiction, surface it: "Your code cancels entire Orders, but you just said partial cancellation is possible — which is right?"

<straw-dog question="q-0037.0010.0001.0001">
### Update glossary.md inline

When a term is resolved, update `docs/glossary.md` right there. Don't batch these up — capture them as they happen. Use the format in [GLOSSARY-FORMAT.md](./GLOSSARY-FORMAT.md).

`docs/glossary.md` should be totally devoid of implementation details. Do not treat it as a spec, a scratch pad, or a repository for implementation decisions. It is a glossary and nothing else.
</straw-dog>

<straw-dog question="q-0037.0010.0002.0005">
### Update architecture.md inline

When high-level architecture of this project changes, update `architecture.md`. Use format in [ARCH-FORMAT.md](./ARCH-FORMAT.md).

`architecture.md` document captures the **high-level architecture**. Lower-level concerns are intentionally **deferred** and listed at the end.
> Scope note: everything here is at the architecture/contract level. Where a concrete shape would prematurely lock a deferred decision, we define only the *seam*.
> You should guide the user toward deep modules with simple boundaries.
</straw-dog>


### Land resolutions as they are made

Land each resolution the moment it is made, as the blocks below say.

<installed by="mechanism-shape">
**R5** Land a mechanism's rule in AGENTS.md only as an installed block from its rules file. While the
mechanism is undeclared, write the rule by hand and wrap it as a straw dog bound to the question
of what the mechanism owns, as you write it.
</installed>

<installed by="ticket">
**P7** Rewrite the ticket in place to what the align's landed decisions make true.

**P10** Open an align by saying what its work is: what it builds and the problem it answers, in plain
words, each of its terms explained, before the necessity gate or any question.

**P11** Sweep the question's body, and the ticket where there is one, for internal consistency at the end:
an early line may still assert what a later resolution changed.
</installed>

<installed by="questions">
**Q6** Land a decision as it is made, with its provenance: final in its durable home where no open
question's answer can change its form or home, otherwise as a straw dog bound to the nearest open
ancestor whose answer can. One with nowhere to land yet — its home is work not done — is a line in
the `## Decisions` list of the lowest question holding everyone who needs it, and takes
`→ <link>` when it lands. Close the question it answers against where it landed, and when a line
lands, repoint every entry closed against its list there. A decision not to do what nothing
instructs lands in its question alone.
</installed>

<installed by="product">
**U2** When a question under *What is this project for?* is decided with something to build, do three
things in one step:

1. With `/product`, write the answer into the document: a row that waits on this question has
   its *waits on* cell emptied; otherwise a new row takes the next number.
2. Close the question against that row.
3. Open the question of how to build it in the *How is this project built?* branch, under the
   question it belongs to, and give it its trace link with `questions.py realize`, naming the
   row's number and name.

A decision that changes, replaces or retires an answer is written by `/product` the same way.
</installed>

<straw-dog question="q-0037.0010.0002.0005">
### Offer ADRs sparingly

Only offer to create an ADR when all three are true:

1. **Hard to reverse** — the cost of changing your mind later is meaningful
2. **Surprising without context** — a future reader will wonder "why did they do it this way?"
3. **The result of a real trade-off** — there were genuine alternatives and you picked one for specific reasons

If any of the three is missing, skip the ADR. Use the format in [ADR-FORMAT.md](./ADR-FORMAT.md).
</straw-dog>

</supporting-info>


---
name: discover
description: >-
  Understand a thing better by asking what it is an instance of outside this
  estate — handed to a separate reasoning process that has none of your context,
  so it answers in other people's vocabulary rather than yours. Use when about to
  say what something is, how it compares with its peers, or what sets it apart;
  when a shape is in front of you and your account of it is the only one you have;
  when about to generalise from one case; or when asked to look at something properly.
  Returns material, never a verdict.
---

<straw-dog question="q-0037.0009.0007">Mechanism: not yet</straw-dog>

# Discover

You are the worst-placed party to say what a thing you built is an instance of. Not for want
of knowledge — you hold a great deal — but because you are reaching for it while holding the
frame that produced the thing, so you retrieve what confirms the shape you already have.

This hands the shape to a process with none of that, and files what comes back.

**It returns material and never a verdict.** What it names is a candidate for your case, not
a finding about it. Why any of this: [EVIDENCE.md](./EVIDENCE.md).

## What it is for, and what it is not

**For:** you hold one account of something and it is the only one you have. You are about to
say what a thing *is*. You have one instance and are about to speak about the class.

**Not for:** ordinary recognition. Naming a thing correctly is not an error, and this does not
fire on plain naming. It fires where the existence you are ascribing has quietly become one
**exhausted by your way of grasping it** — where your handle on the thing has replaced it.

**Never the reason to change something.** A ladder always has a higher rung, so a pass will
always return room for improvement; that is the shape of the question rather than
information. Its output informs a change that already has a reason. A pass that motivates
work has inverted, and the honest name for that is worthening.

## Run it

**Ask the question the shape answers, not the shape:** what it is for, the situation it serves,
without how this tree meets it — a shape described, in anyone's words, sends its frame along. No
local file names, no local rule numbers, no local record names, no house terms. If the pass can only answer in your
words, it never left — and this is the whole of the method, so it is worth more care than the
rest of the tasking put together.

**Transmit the frame as little as the subject allows, and say what you transmitted.** The
capture that matters is not the vocabulary of your files; it is the framing you cannot help
sending, and a fresh process does not fix that by itself. A pass told what to look for will
find it and the finding will be worth nothing.

**Give it the rules it works under**, written into the tasking — they are the pass's own
instructions, not yours. Ask it for several families rather than one, each with where this sits on
that family's own ladder, what the family already knows about how this goes wrong, and its
confidence per claim.

**Ask it to name what your tasking smuggled in.** A first-class answer, and the one most
likely to be the useful part.

## Sort what comes back

**Recency for evidence, longevity for principles.** A claim that something *works* is
evidence and must come from the same substrate, recent enough to be about it. A claim about
how things of this shape behave in general is a principle, and there **longevity** qualifies —
which is continued life, not elapsed time: still cited, still taught, still used to decide
things. A dead old idea has age and no longevity. **The same source flips value depending on
which you asked it for**, and nothing about the source changes.

**Several doors, not one.** A family is a full alternative approach to the thing, not a slice
of it. So a disagreement between families is not a defect to resolve into one account — an
answer that harmonises them has probably lost both.

**Structural fit, not topical.** Retrieval is cued by surface features, so an unconstrained
*what is this like* returns subject-matter neighbours sharing no structure. Refuse a family
whose mapping cannot be stated.

**Stop where no further grounds appear.** Depth is a consequence of that, never a parameter.

## How to run it

**Spawn a separate process** — a general-purpose subagent — and tell it not to read this
repository. Reading it re-contaminates, which is the one thing the separate process buys.
Unless the shape is the repository itself: then the repository is the subject, and your
description of it is the frame. The pass reads it cold, from a fresh clone, and gets only the
question.

**Never feed one pass into the next.** A pass given an earlier pass's output retrieves what it
already said, and the second isolation buys nothing.

**Put the material into the work as it came back.** A summary written before you use it is your
reading of the pass, which is the contamination the pass exists to escape. It goes into the body of
the question that prompted it, the way `/impact`'s does.

## Neighbours

The two passes are a pair, and the overlap is intentional. [/impact](../impact/SKILL.md) is
the first pass: what a shape is made of here, and what depends on it — it needs the corpus.
This is the second: what the shape is an instance of elsewhere — it must not read the corpus.
Running both means two processes with opposite permissions, which is the point of having two.

[/align](../align/SKILL.md) stress-tests a shape with a person in the room; this runs without
one. A third pass, where a shape wants to go, is not built.

Output only:

## Families
Each an alternative account of the shape — not a slice of one. For each: where this sits on that
family's own ladder, what the family already knows about how this goes wrong, and confidence per
claim.

## What the tasking smuggled in
The framing the pass could see in how it was asked.

## Nothing to take
Families refused for want of a statable mapping, and — when it applies — that the pass returned no
usable material. That is a result, not a failed run.
