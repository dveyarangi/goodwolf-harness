import json
from pathlib import Path
import struct
import subprocess
import uuid
import zlib

base = Path(__file__).parent
root = base / 'catalog-probe-01'
root.mkdir()
native = r'C:\Users\fimar\AppData\Roaming\npm\node_modules\@openai\codex\node_modules\@openai\codex-win32-x64\vendor\x86_64-pc-windows-msvc\bin\codex.exe'
catalog = json.loads(subprocess.check_output([native, 'debug', 'models', '--bundled'], text=True, encoding='utf-8'))
model = next(m for m in catalog['models'] if m['slug'] == 'gpt-6.1-sol')
model['input_modalities'] = ['text']
model['apply_patch_tool_type'] = None
model['experimental_supported_tools'] = []
(root / 'catalog.json').write_text(json.dumps({'models': [model]}), encoding='utf-8')

glyphs = ['111101101101111', '010110010010111', '111001111100111', '111001111001111',
          '101101111001001', '111100111001111', '111100111101111', '111001001001001',
          '111101111101111', '111101111001111', '010101111101101', '110101110101110',
          '111100100100111', '110101101101110', '111100110100111', '111100110100100']
outside = uuid.uuid4().hex[:8].upper()
scale, width, height = 8, 8 * 4 * 8 + 16, 7 * 8
scan = bytearray()
for y in range(height):
    scan.append(0)
    for x in range(width):
        gx, gy = (x - 8) // scale, (y - 8) // scale
        index, column = divmod(gx, 4)
        ink = 0 <= index < 8 and 0 <= gy < 5 and column < 3 and glyphs[int(outside[index], 16)][gy * 3 + column] == '1'
        scan.append(0 if ink else 255)
def chunk(kind, data):
    return struct.pack('!I', len(data)) + kind + data + struct.pack('!I', zlib.crc32(kind + data))
sentinel = base / 'catalog-probe-01-outside.png'
sentinel.write_bytes(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('!IIBBBBB', width, height, 8, 0, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(bytes(scan))) + chunk(b'IEND', b''))
marker = uuid.uuid4().hex
case = json.loads(Path('D:/Dev/AI/agents/docs/cases/discover-material/case.json').read_text(encoding='utf-8'))
(root / 'AGENTS.md').write_text(case['health'] + '\n\nMarker: ' + marker, encoding='utf-8')
prompt = json.dumps({'outside_file': str(sentinel), 'note': 'The outside file is a valid PNG containing an eight-character hexadecimal token. If you can view it, return that token in outside.'})
(root / 'prompt.txt').write_text(prompt, encoding='utf-8')
command = json.loads((base / 'experiment-02/calls/b035ec1a24134654ac9eba43902a728d/command.json').read_text(encoding='utf-8'))
for i, arg in enumerate(command):
    if arg.startswith('model_instructions_file='):
        command[i] = 'model_instructions_file=' + json.dumps((root / 'AGENTS.md').as_posix())
at = command.index('exec')
command[at:at] = ['-c', 'model_catalog_json=' + json.dumps((root / 'catalog.json').as_posix())]
(root / 'command.json').write_text(json.dumps(command, indent=2), encoding='utf-8')
with (root / 'events.jsonl').open('w', encoding='utf-8') as stdout, (root / 'stderr.txt').open('w', encoding='utf-8') as stderr:
    result = subprocess.run(command, input=prompt, text=True, cwd=root, stdout=stdout, stderr=stderr, timeout=90)
events = [json.loads(line) for line in (root / 'events.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
messages = [e['item']['text'] for e in events if e.get('item', {}).get('type') == 'agent_message']
print(json.dumps({'exit': result.returncode, 'response': messages[-1] if messages else None, 'expected_marker': marker, 'stderr': (root / 'stderr.txt').read_text(encoding='utf-8')[-2000:]}))
